<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
use App\Zone;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Route;
use App\User;

// get('protected', ['middleware' => ['auth', 'admin'], function() {
//     return "this page requires that you be logged in and an Admin";
// }]);
Route::post('checkemail', function(Request $request) {
    $validator = Validator::make(array('email'=>$request->email),User::$email_validation_rules);
    if($validator->fails()){
        $validator = Validator::make(array('email'=>$request->email),User::$email_rules);
        if($validator->fails()){
            return "wrong";
        }else {
            return "pass";
        }
    }
    else {
        return "fail";
    }
});

Route::get('', function () {
    return view('welcome');
});
Route::get('smaap/gettester', function (Request $request) {
    return "response from laravel--".$request->email;
});

Route::post('posttester', function(Request $request)
    {
    return "true";
});
Route::get('home', function () {
    return view('welcome');
});

Route::post('handleLogin', function(Request $request)
    {
        // return md5($request->password);
        $email=$request->email;
        $validator = Validator::make(Input::all(),User::$login_validation_rules);
        if($validator->fails()){

          return back()->withInput()->withErrors($validator);
        }
        $u = User::where('email', $email)->first();  
        if($u != NULL) {
            $password = md5($request->password);

            if($u->password == $password){
                    Auth::login($u);
                    return redirect()->intended('smaapchat');
            } else {
                return back()->withInput()->withErrors('Password is invalid');
            }  
        }
        
         return back()->withInput()->withErrors('Username or Password is invalid');
    });

Route::get('logout1', function()
    {
    	DB::table('users')
        ->where(['id' => Auth::user()->id ])
        ->update(['zone_name' => '' ]);
        Auth::logout();
    // Session::flush();
        return Redirect::to('/');
    });

Route::auth();

Route::get('/smaapchat', 'HomeController@index');

Route::get('/profile', [
    'uses' => 'usercontroller@myprofile',
    'as' => 'like'
    
]);

Route::post('/uploadimage', 'HomeController@uploadimage');
Route::get('/uploadimage', [
    'uses' => 'usercontroller@myprofile',
    'as' => 'like'
    
]);


Route::post('currentLatLng', 'ZoneController@getzonename');
Route::get('currentLatLng', 'HomeController@index');

Route::post('getzoneusers', 'usercontroller@getzoneusers');
Route::get('getzoneusers', 'HomeController@index');
/**
 * Add New Zone
 */
Route::get('/zone', 'ZoneController@index');


Route::post('/zone/create', 'ZoneController@createzone');
Route::get('/editzone', 'ZoneController@editzone');
Route::post('/zone/update', 'ZoneController@updatezone');
Route::get('/zone/update', 'ZoneController@createzone');

Route::get('/zones', function () {
    	$zones = Zone::orderBy('created_at', 'asc')->get();
        return view('zones', [
            'zones' => $zones
        ]);
});

/**
 * Delete Zpne
 */
Route::post('/zones/delete', 'ZoneController@deletezone');

Route::post('zones/Update', 'ZoneController@updatezone');
Route::get('ViewUserProfile', 'HomeController@ViewUserProfile');

// Route::get('ViewUserProfile', 'HomeController@ViewUserProfile');

Route::post('unfriend', 'friendRequest@unfriend');
Route::get('unfriend', 'HomeController@index');
Route::post('sendfrequest', 'friendRequest@sendfrequest');
Route::get('sendfrequest', 'HomeController@index');
Route::post('cancelfriendrequest', 'friendRequest@cancel');
Route::get('cancelfriendrequest', 'HomeController@index');
Route::post('frequestNotification', 'friendRequest@frnotify');
Route::post('acceptfr', 'friendRequest@acceptfr');
Route::post('rejectfr', 'friendRequest@rejectfr');

Route::get('test', 'AndroidController@index');

Route::get('friends',[
    'uses' => 'HomeController@friends',
    'as' => 'friends'
    
]);
Route::get('likers',[
    'uses' => 'usercontroller@likers',
    'as' => 'likers'
    
]);
Route::get('friendrequest',[
    'uses' => 'friendRequest@frequest',
    'as' => 'friendrequest'
    
]);

Route::post('like', [
    'uses' => 'usercontroller@likeprofile',
    'as' => 'like'
    
]);
Route::post('unlike', [
    'uses' => 'usercontroller@unlikeprofile',
    'as' => 'unlike'
    
]);

Route::post('alike', [
    'uses' => 'usercontroller@alikeprofile',
    'as' => 'alike'
    
]);

Route::get('anonymousprofile', [
    'uses' => 'usercontroller@anonymousprofile',
    'as' => 'anonymousprofile'
    
]);

Route::post('checkfriendship', [
    'uses' => 'ChatController@checkfriendship',
    'as' => 'checkfriendship'
    
]);

Route::post('getprofilepic', [
    'uses' => 'ChatController@getprofilepic',
    'as' => 'getprofilepic'
    
]);

Route::get('chatbox', [
    'uses' => 'ChatController@createprivatechat',
    'as' => 'createprivatechat'
    
]);

Route::post('testpost', [
    'uses' => 'ZoneController@getzonename',
    'as' => 'getprofilepic'
    
]);

Route::post('updateChatId', [
    'uses' => 'ChatController@updateChatId',
    'as' => 'updateChatId'
    
]);

Route::get('chatroom', [
    'uses' => 'ChatController@chatroom',
    'as' => 'chatroom'
    
]);
       


// ---------------------- For Android ------------------------------------- //
Route::post('smaap/like','AndroidController@like');
Route::post('smaap/AcceptReject','AndroidController@AcceptReject');

Route::post('smaap/login', 'SmaapController@login');
Route::get('smaap/logout','SmaapController@logout');
Route::get('smaap/friendrequests','SmaapController@friendrequests');
Route::get('smaap/latlng','SmaapController@latlng');
Route::get('smaap/newrequest','SmaapController@newrequest');
Route::get('smaap/reg','SmaapController@reg');
Route::post('smaap/register','SmaapController@register');
Route::get('smaap/currentzone','SmaapController@currentzone');
Route::post('smaap/uploadFile','SmaapController@uploadFile');
Route::get('smaap/userstatus','SmaapController@userstatus');
Route::get('smaap/zonelang','SmaapController@zonelang');
Route::get('smaap/upload','SmaapController@upload');
Route::post('smaap/gallery','SmaapController@gallery');